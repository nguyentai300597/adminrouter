import 'package:flutter/material.dart';

const TextStyle kNumTextStyle =  TextStyle(fontSize: 35,fontWeight: FontWeight.w500,color: Colors.white);