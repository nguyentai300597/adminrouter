package com.example.lancealot_admin_panel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
